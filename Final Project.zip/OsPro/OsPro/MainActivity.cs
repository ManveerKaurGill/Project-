﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Content;

namespace OsPro
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        ArrayAdapter Aadapter;
        SearchView View;
        ListView ViewList;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
            Button addButton = FindViewById<Button>(Resource.Id.button1);

            addButton.Click += delegate
            {
                Intent intent = new Intent(this, typeof(Registeration));
                StartActivity(intent);
            };

            View = FindViewById<SearchView>(Resource.Id.searchView1);
            View.QueryTextChange += (s, e) =>
            {
                Aadapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, Employee.Employees);
                ViewList.Adapter = Aadapter;
                Aadapter.Filter.InvokeFilter(e.NewText);
            };

           ViewList = FindViewById<ListView>(Resource.Id.listView1);
            ViewList.ItemClick += (s, e) =>
            {
                string textId = Aadapter.GetItem(e.Position).ToString();

                textId = textId.Substring(textId.IndexOf("\n") + 5);
                int position = Employee.Ids.IndexOf(textId);

                Intent intent = new Intent(this, typeof(Edata));
                intent.PutExtra("Position", position);
                StartActivity(intent);
            };




        }

        protected override void OnRestart()
        {
            base.OnRestart();
            View.SetQuery("", false);
            Aadapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, Employee.Employees);
            ViewList.Adapter = Aadapter;
        }
    }
}