﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace OsPro
{
    [Activity(Label = "Edata")]
    public class Edata : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.results);
            int position = Intent.GetIntExtra("Position", -1);

            Employee.Employees.ElementAt(position).List = false;

            TextView profile = FindViewById<TextView>(Resource.Id.lastTextview);
            profile.Text = Employee.Employees.ElementAt(position).ToString();
        }
    }
}