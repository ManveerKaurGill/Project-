﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace OsPro
{
    [Activity(Label = "Registeration")]
    public class Registeration : Activity
    {

        EditText EditFirst;
        EditText EditLast;
        EditText EditYear;
        EditText EditSalary;
        EditText EditOccupation;
        EditText EditId;
        EditText EditProperty;
        EditText EditCar;
        EditText EditModel;
        EditText EditPlate;

        Spinner SpinnerColor;
        Spinner SpinnerType;
        TextView textViewProperty;

        RadioButton RadioCar;
        RadioButton RadioMotorbike;
        RadioButton RadioYes;
        RadioButton RadioNo;

        bool? hasSideCar;
        double occupationRate;
        string name;
        string employeeType;
        string vehicleColor;
        string vehicleCategory;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.registration);

            EditFirst = FindViewById<EditText>(Resource.Id.nameFirst);
            EditLast = FindViewById<EditText>(Resource.Id.nameLast);
            EditYear = FindViewById<EditText>(Resource.Id.yearBirth);
            EditSalary = FindViewById<EditText>(Resource.Id.incomeSalary);
            EditOccupation = FindViewById<EditText>(Resource.Id.rateOccupation);
            EditId = FindViewById<EditText>(Resource.Id.idEmployee);
            SpinnerType = FindViewById<Spinner>(Resource.Id.spinner1);
            textViewProperty = FindViewById<TextView>(Resource.Id.bugsTextview);
            EditProperty = FindViewById<EditText>(Resource.Id.bugEdit);
            RadioCar = FindViewById<RadioButton>(Resource.Id.radioCar);
            RadioMotorbike = FindViewById<RadioButton>(Resource.Id.radioMoto);
            RadioYes = FindViewById<RadioButton>(Resource.Id.radioButton1);
            RadioNo = FindViewById<RadioButton>(Resource.Id.radioButton2);
            EditCar = FindViewById<EditText>(Resource.Id.carType);
            EditModel = FindViewById<EditText>(Resource.Id.model);
            EditPlate = FindViewById<EditText>(Resource.Id.plate);
            SpinnerColor = FindViewById<Spinner>(Resource.Id.colorful_gay);

            Button registerButton = FindViewById<Button>(Resource.Id.buttonMyBalls);

            var adapterEmployeeTypes = ArrayAdapter.CreateFromResource(this, Resource.Array.items_type, Android.Resource.Layout.SimpleSpinnerItem);
            adapterEmployeeTypes.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            SpinnerType.Adapter = adapterEmployeeTypes;
            SpinnerType.ItemSelected += employeeTypeSpinner_ItemSelected;
            SpinnerType.ItemSelected += delegate
            {
                string msg = SpinnerType.SelectedItem + " is the selected employee ";
                Toast.MakeText(this, msg, ToastLength.Short).Show();


            };


            var adapterVehicleColor = ArrayAdapter.CreateFromResource(this, Resource.Array.items_colors, Android.Resource.Layout.SimpleSpinnerItem);
            adapterVehicleColor.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            SpinnerColor.Adapter = adapterVehicleColor;
            SpinnerColor.ItemSelected += VehicleColorSpinner_ItemSelected;
            SpinnerColor.ItemSelected += delegate
            {
                string msg = SpinnerColor.SelectedItem + " is the selected Color ";
                Toast.MakeText(this, msg, ToastLength.Short).Show();


            };


            RadioCar.Click += VehicleCategoryClick;
            RadioMotorbike.Click += VehicleCategoryClick;
            RadioYes.Click += SideCarClick;
            RadioNo.Click += SideCarClick;
            registerButton.Click += RegisterClick;


        }

        private void RegisterClick(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(EditFirst.Text) && !string.IsNullOrEmpty(EditLast.Text) && !string.IsNullOrEmpty(EditYear.Text) && !string.IsNullOrEmpty(EditSalary.Text) && !string.IsNullOrEmpty(EditOccupation.Text) &&
                !string.IsNullOrEmpty(EditId.Text) && !employeeType.Equals("Please Choose a type") && !string.IsNullOrEmpty(EditProperty.Text) && !string.IsNullOrEmpty(EditModel.Text) && !string.IsNullOrEmpty(EditPlate.Text) &&
           !vehicleColor.Equals(" Please Choose a color"))
            {
                if (!Employee.Ids.Contains(EditId.Text))
                {
                    name = EditFirst.Text + " " + EditLast.Text;

                    int birthYear = Convert.ToInt32(EditYear.Text);
                    if ((birthYear < 1900) || (birthYear > DateTime.Now.Year))
                    {
                        Toast.MakeText(this, $"Error!\n Value must be greater than 1980 "
                            , ToastLength.Long).Show();
                    }
                    else
                    {
                        int age = (DateTime.Now.Year - birthYear);

                        occupationRate = Convert.ToDouble(EditOccupation.Text) / 100;

                        if (occupationRate < 0.1)
                        {
                            occupationRate = 0.1;

                        }
                        else if (occupationRate > 1)
                        {
                            occupationRate = 1;
                        }

                        if (employeeType.Equals("Manager"))
                        {



                            if (vehicleCategory.Equals("Car"))
                            {
                                Car car = new Car(vehicleCategory, EditCar.Text, EditModel.Text, EditPlate.Text, vehicleColor);
                                Manager m = new Manager(name, age, EditYear.Text, EditSalary.Text, occupationRate, EditId.Text,
                                    employeeType, EditProperty.Text, car);
                                Employee.Employees.Add(m);
                            }
                            else if (vehicleCategory.Equals("Motorbike"))
                            {
                                Motorbike moto = new Motorbike(vehicleCategory, hasSideCar, EditModel.Text, EditPlate.Text, vehicleColor);
                                Manager m = new Manager(name, age, EditYear.Text, EditSalary.Text, occupationRate, EditId.Text,
                                    employeeType, EditProperty.Text, moto);
                                Employee.Employees.Add(m);
                            }
                        }
                        else if (employeeType.Equals("Tester"))
                        {
                            if (vehicleCategory.Equals("Car"))
                            {
                                Car car = new Car(vehicleCategory, EditCar.Text, EditModel.Text, EditPlate.Text, vehicleColor);
                                Tester t = new Tester(name, age, EditYear.Text, EditSalary.Text, occupationRate, EditId.Text,
                                    employeeType, EditProperty.Text, car);
                                Employee.Employees.Add(t);
                            }
                            else if (vehicleCategory.Equals("Motorbike"))
                            {
                                Motorbike moto = new Motorbike(vehicleCategory, hasSideCar, EditModel.Text, EditPlate.Text, vehicleColor);
                                Tester t = new Tester(name, age, EditYear.Text, EditSalary.Text, occupationRate, EditId.Text,
                                    employeeType, EditProperty.Text, moto);
                                Employee.Employees.Add(t);
                            }
                        }
                        else if (employeeType.Equals("Programmer"))
                        {

                            if (vehicleCategory.Equals("Car"))
                            {
                                Car car = new Car(vehicleCategory, EditCar.Text, EditModel.Text, EditPlate.Text, vehicleColor);
                                Programmer p = new Programmer(name, age, EditYear.Text, EditSalary.Text, occupationRate,
                                    EditId.Text, employeeType, EditProperty.Text, car);
                                Employee.Employees.Add(p);
                            }
                            else if (vehicleCategory.Equals("Motorbike"))
                            {
                                Motorbike moto = new Motorbike(vehicleCategory, hasSideCar, EditModel.Text, EditPlate.Text, vehicleColor);
                                Programmer p = new Programmer(name, age, EditYear.Text, EditSalary.Text, occupationRate,
                                    EditId.Text, employeeType, EditProperty.Text, moto);
                                Employee.Employees.Add(p);
                            }
                        }

                        Employee.Ids.Add(EditId.Text);

                        Finish();
                    }

                }
                else
                {
                    Toast.MakeText(this, "Error!\nThis employee is already registered", ToastLength.Long).Show();
                }

            }
            else
            {
                Toast.MakeText(this, "Error!\nMake sure all the fields are filled", ToastLength.Long).Show();
            }

        }


        private void SideCarClick(object sender, EventArgs e)
        {
            RadioButton rbSideCar = (RadioButton)sender;

            switch (rbSideCar.Text)
            {
                case "Yes":
                    hasSideCar = true;
                    break;
                case "No":
                    hasSideCar = false;
                    break;
                default:
                    hasSideCar = null;
                    break;

            }
        }

        private void VehicleCategoryClick(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            string choose = (rb.Text);

            if (choose == "car")
            {
                TableRow tr = FindViewById<TableRow>(Resource.Id.row_car_type);
                tr.Visibility = Android.Views.ViewStates.Visible;
                vehicleCategory = "Car";
            }

            if (choose == "motorbike")
            {
                TableRow tr = FindViewById<TableRow>(Resource.Id.row_side);
                tr.Visibility = Android.Views.ViewStates.Visible;
                vehicleCategory = "Motorbike";
            }
        }

        private void VehicleColorSpinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            vehicleColor = SpinnerColor.GetItemAtPosition(e.Position).ToString();
        }

        private void employeeTypeSpinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            Spinner spinner = (Spinner)sender;
            int item = (int)spinner.SelectedItemId;

            if (item == 1)
            {
                TableRow tr = FindViewById<TableRow>(Resource.Id.rowgone);
                tr.Visibility = Android.Views.ViewStates.Visible;
                TextView tv = FindViewById<TextView>(Resource.Id.bugsTextview);
                tv.Text = "# clients";
                employeeType = "Manager";
            }

            if (item == 2)
            {
                TableRow tr = FindViewById<TableRow>(Resource.Id.rowgone);
                tr.Visibility = Android.Views.ViewStates.Visible;
                TextView tv = FindViewById<TextView>(Resource.Id.bugsTextview);
                tv.Text = "# bugs";
                employeeType = "Tester";
            }

            if (item == 3)
            {
                TableRow tr = FindViewById<TableRow>(Resource.Id.rowgone);
                tr.Visibility = Android.Views.ViewStates.Visible;
                TextView tv = FindViewById<TextView>(Resource.Id.bugsTextview);
                tv.Text = "# projects";
                employeeType = "Programmer";
            }

        }
    }
}